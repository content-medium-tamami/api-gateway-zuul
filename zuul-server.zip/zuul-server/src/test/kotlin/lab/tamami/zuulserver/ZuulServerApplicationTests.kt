package lab.tamami.zuulserver

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ZuulServerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
